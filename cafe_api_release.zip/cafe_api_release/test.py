import mysql.connector
import configparser

# Read credentials from a configuration file
config = configparser.ConfigParser()
config.read('config.ini')

db_host = config['database']['host']
db_name = config['database']['name']
db_user = config['database']['user']
db_password = config['database']['password']

def test_db_connection():
    try:
        connection = mysql.connector.connect(
            host=db_host,
            database=db_name,
            user=db_user,
            password=db_password
        )
        if connection.is_connected():
            print("Successfully connected to the database")
            connection.close()
        else:
            print("Failed to connect to the database")
    except mysql.connector.Error as err:
        print("Error connecting to database:", err)

if __name__ == "__main__":
    test_db_connection()
